/**13. Escriba un ejercicio de JavaScript para crear una variable con un nombre
definido por el usuario. */

var var_name = 'hhh';
var n = prompt("Introduzca el nombre de la variable:");

this[var_name] = n;
document.write(this[var_name])