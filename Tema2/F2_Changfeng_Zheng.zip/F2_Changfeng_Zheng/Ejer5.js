/** 12. Escriba un programa JavaScript para obtener la URL del sitio web (página de
carga).*/

var URLactual = window.location;
document.write(URLactual);
