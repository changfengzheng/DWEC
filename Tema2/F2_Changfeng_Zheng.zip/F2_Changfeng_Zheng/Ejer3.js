/** 10.Escriba un programa JavaScript para calcular la multiplicación y división de dos
números (entrada del usuario). */

let num1;
let num2;

num1 = parseInt(prompt("Ingrese primer el numero"));
num2 = parseInt(prompt("Ingrese segunda el numero"));


document.write(num1 * num2), "<br>";
document.write(num1 / num2);