/**14. Escriba un ejercicio de JavaScript para obtener la extensión de un nombre de
archivo. */

let archivo = "hola.txt";
document.write(archivo.split(".").pop());


